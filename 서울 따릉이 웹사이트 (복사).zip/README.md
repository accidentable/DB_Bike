
  # 서울 따릉이 웹사이트 (복사)

  This is a code bundle for 서울 따릉이 웹사이트 (복사). The original project is available at https://www.figma.com/design/bdMV6RgvlXnFJwQKjN2Ig1/%EC%84%9C%EC%9A%B8-%EB%94%B0%EB%A6%89%EC%9D%B4-%EC%9B%B9%EC%82%AC%EC%9D%B4%ED%8A%B8--%EB%B3%B5%EC%82%AC-.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  